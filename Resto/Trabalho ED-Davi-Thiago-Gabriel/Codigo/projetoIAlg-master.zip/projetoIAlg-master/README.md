# games
Projeto para a matéria de Introdução aos Algoritmos do curso de Ciências da Computação da Univerdade Federal de Lavras de um sistema de cadastro de games.
Membros do grupo:
1) Lucas Neves
2) Luiz Conde
3) Thiago Luigi
